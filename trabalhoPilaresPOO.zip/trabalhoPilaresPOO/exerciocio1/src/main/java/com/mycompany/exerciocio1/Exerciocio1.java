/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exerciocio1;

/**
 *
 * @author Bruno Stefanello
 */
public class Exerciocio1 {

    public static void main(String[] args) { 
        
        Retangulo retangulo = new Retangulo();
        Circulo circulo = new Circulo();
        
        circulo.calcularArea();
        retangulo.calcularArea();
                
    }
}
