/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exerciocio2;

/**
 *
 * @author Bruno Stefanello
 */
public class Exerciocio2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
