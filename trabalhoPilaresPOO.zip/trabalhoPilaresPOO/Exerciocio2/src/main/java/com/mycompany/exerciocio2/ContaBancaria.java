/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exerciocio2;

/**
 *
 * @author Bruno Stefanello
 */
public class ContaBancaria {
    public double saldo;
    public String titular;
    
    public ContaBancaria(double saldo, String titular){
        this.saldo = saldo;
        this.titular = titular;
    }
}
